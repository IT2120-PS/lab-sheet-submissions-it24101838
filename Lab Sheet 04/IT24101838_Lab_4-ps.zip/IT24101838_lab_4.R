#setting directory
setwd("C:/Users/IT24101838/Desktop/IT24101838")

#importing the dataset
dta<-read.table("data 4.txt",header=TRUE,sep="")

#view the file in a separate window
fix(data)

#attach the file into R 
attach(data)

#obtining box plots
boxplot(x1,main="box plot for team attendence",outline=TRUE,outpch=8,horizontl=TRUE)
boxplot(x2,main="box plot for team slary",outline=TRUE,outpch=8,horizontl=TRUE)
boxplot(x3,main="box plot for team years",outline=TRUE,outpch=8,horizontl=TRUE)

#obtaining histogram
hist(x1,ylab="frequency",xlab="team attendence",min="histogram for team attendence")
hist(x2,ylab="frequency",xlab="team salary",min="histogram for team salary")
hist(x3,ylab="frequency",xlab="years",min="histogram for years")

#stem & leaf plot
stem(x1)
stem(x2)
stem(x3)

#mean
mean(x1)
mean(x2)
mean(x3)

#median
median(x1)
median(x2)
median(x3)

#standrd devition
sd(x1)
sd(x2)
sd(x3)

#getting five number summary along with mean value
summary(x1)
summary(x2)
summary(x3)

#getting only five number summary for x1 variable
guantile(x1)

#calling first quartile of x1 varible
quantile(x1)[2]

#calling third qurtile of x1 using index value
quantile(x1)[4]

#obtaining inter qurtile range (IQR) of each vrible
IQR(x1)
IQR(x2)
IQR(x3)

#function to get the mode of a data set
get.mode<-function(y){
  counts<-table(x3)
  name(counts[counts==max(counts)])
}

#obtaining the mode of a variable using the function defined above
get.mode(x3)

#following command is to get the frequency table for the variable
table(x3)

#following command will give the maximum freaquency table 
mac(counts)

#function to check the existence of outliers of a data set
get.outliers<-function(2){
  q1<-quqntile(2)[2]
  q1<-quqntile(2)[4]
}




























setwd("C:/Users/IT24101838/Desktop/IT24101838")
getwd()
branch_data <- read.table("Exercise.txt", header = TRUE)
head(branch_data)


str(branch_data)
sapply(branch_data, class)
 
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", col="lightblue")
summary(branch_data$Sales_X1)


fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)
 

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}
find_outliers(branch_data$Years)
